public int recipeScore(Recipe recipe){

  int score = 0;

  for(int i = 0; i < userList.length; i++) {
    if(recipe.getIngredientList.contains(userList[i])) {
      score++;
    }
  }
  return score;
}
  if(recipe.getIngredientList.contains())
  for(int i = 0; i < recipe.getIngredientList().length; i++) {
    
    for(int j = 0; j < userList.length; j++) {
      if(recipe.getIngredientList()[i].equalsIgnoreCase(userList[j]) {
        score++;
        if(recipe.ingredientList.contains)
    }
   
  }
  
  var counter = 0;
  for(var i = 0; i < availableIngredients.length; i++) {

  }
  //Ignore
  int counter = 0;
  for(int i = 0; i < availableIngredients.length; i++) {
    for(int j = 0; j < )
  }
}